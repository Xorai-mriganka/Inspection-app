import './App.css';
import Header from './Header';
import Mid from './Mid';
import Footer from './Footer';
import React, { Component } from 'react'


function App() {
  return (
    <div className="App">
       <Header />
      <Mid />
      <Footer />
    </div>
  )
}



export default App;
